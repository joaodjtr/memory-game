# Cereal Airbnb Font

![My image](https://github.com/huuphongnguyen/phong.github.io/raw/master/cereal.png)

### What can you do with these font files? ![CI status](https://img.shields.io/badge/File%3A-TTF-%2330fff1.svg)  [![CI status](https://img.shields.io/badge/huuphongnguyen-.com-%23020977.svg)](https://huuphongnguyen.com)  ![CI status](https://img.shields.io/badge/Purpose%3A-Font-%23027AFF.svg)

* See it on Product Hunt and want to use it 🤭
* Typography 🤔
* For research 🧐

![My image](https://raw.githubusercontent.com/huuphongnguyen/phong.github.io/master/AirbnbCerealWeights-1.jpg)

### Enjoy it 🙌
